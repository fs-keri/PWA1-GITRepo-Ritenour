/**
 * Name: Keri Ritenour
 * Date: 9/27/2015
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 */


//Create the Person Constructor using name and row number


//Create the prototype for the Person name, action, job and row


//populate HTML