/**
 * Name: Keri Ritenour
 * Date: 9/27/2015
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 */

//Create an array called Names and populate with people names


//Create a for loop that randomly selects 3 instances of the people object


//Create an array called People that will store names selected from th


//Instantiate the Person object; pass the random name and row number to the constructor

//Ensure no duplicate names are selected

//Create an Interval to call after a specified time of 1 every 30 seconds

//Pass the results of the loop to populate the html corresponding to row and column number
